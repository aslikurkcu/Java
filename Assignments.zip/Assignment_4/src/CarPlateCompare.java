import java.util.Comparator;

public class CarPlateCompare implements Comparator<Service> {

public int compare(Service s1, Service s2){
	
	return s1.getCarPlate().compareTo(s2.getCarPlate());
	
}

}

