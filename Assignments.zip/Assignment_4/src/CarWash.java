
public class CarWash extends Service {

final static double basePrice = 10.0;	
	
	CarWash(String carPlate) {
		super(carPlate);
	}

@Override
public double calculate() {
		
	System.out.printf("%s","class CarWash: ");
	
	setRevenue(basePrice);
	return getRevenue();
}
@Override
public double makeTransaction(double basePrice){
	
	double total = basePrice;
	super.makeTransaction(total);
	return 0;
}

@Override
public void displayServiceInfo() {
		System.out.println();
		System.out.println("Car Wash service...");
		super.displayServiceInfo();	
}


}
