
public class GasolineService extends FuelService {
	
	private boolean hasCoupon;
	
	GasolineService(String carPlate, double literBought, boolean hasCoupon){
		
		super(carPlate,literBought);
		this.hasCoupon = hasCoupon;	
	}

@Override
public void displayServiceInfo() {
		
	System.out.println();
	System.out.println("Gasoline Service...");
	super.displayServiceInfo();
		
	if (hasCoupon == true) {
			
	System.out.println("Has 10% discount coupon" );
	}
}
	
@Override
public double makeTransaction(double avarageGasolinePrice) {
		
	double total = 0.0;
	if (hasCoupon == true) {
		total = (avarageGasolinePrice * getLiterBought() )* 0.9 ;
	}else {
		total = avarageGasolinePrice * getLiterBought();
	}
	super.makeTransaction(total);
	return 0;	
}

@Override
public double calculate() {
	
	System.out.printf("%s","class GasolineService ");
	return getRevenue();
	}

}
