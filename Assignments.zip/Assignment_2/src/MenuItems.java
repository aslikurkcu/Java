enum MenuItems {
	
	M1("Create a new station"),
	M2("Add gasoline to a statiton inventory"), 
	M3("Add diesel to a statiton inventory"), 
	M4("Display a station inventory"), 
	M5("Sell gasoline to customer"),
	M6("Sell diesel to customer"), 
	M7("Sell diesel to customer"), 
	M8("Sell diesel to customer"), 
	M9("Sell diesel to customer"), 
	M10("Sell diesel to customer"), 
	M11("Exit");

	private String menu ;

	MenuItems(String m) {
		menu = m;
	}

	String getMenu() {
		return menu;
	}
	
	static void printMenu() {
		System.out.println("1.Create a new station");
		System.out.println("2.Add gasoline to a statiton inventory");
		System.out.println("3.Add diesel to a statiton inventory");
		System.out.println("4.Display a station inventory");
		System.out.println("5.Sell gasoline to customer");
		System.out.println("6.Sell diesel to customer");
		System.out.println("7.Display sold services so far");
		System.out.println("8.Exit");
	}
}
