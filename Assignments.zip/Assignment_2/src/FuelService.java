
public class FuelService extends Service{

	double literBought;
	
	FuelService(String carPlate, double literBought){
		
		super(carPlate);
		this.literBought = literBought;		
	}
		
	public void displayServiceInfo() {
		
		System.out.println("Bought " + literBought + " liters.");
		super.displayServiceInfo();
	}
	
	public double makeTransaction(double price){
		super.makeTransaction(price);
		return 0;
	}
}