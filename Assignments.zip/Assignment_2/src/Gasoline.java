import java.util.Scanner;

public class Gasoline {
	String origin;
	double pricePerLiter;
	double totalLiters;
	
	public Gasoline() 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.printf("%s","Please enter the origin of gasoline: ");
	    origin = scanner.next();
		
		System.out.printf("%s","Please enter the price per liter: ");
		pricePerLiter = scanner.nextDouble();
		
		System.out.printf("%s","Please enter the total shipment volume in liter: ");
		totalLiters = scanner.nextDouble();	
	}
	
	
 public void displayGasoline() {
	
	System.out.println("Gasoline...");
	System.out.println("The origin is: " + origin);
	System.out.println("Price per liter is: " + pricePerLiter );
	System.out.println("Total liters of this gasoline is: " + totalLiters);
}
}
