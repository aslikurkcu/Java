import java.util.Scanner;

public class Station {
	
	String stationName;
	int ID;
	Gasoline[] gasolineArray;
	Diesel[] dieselArray;
	int gasoline = 0;
	int diesel = 0; 
	int serviceG = 0;
	Service[] serviceArray;
	static double averageGasolinePrice;
	static double totalGasolineInStation;
	static double averageDieselPrice;
	static double totalDieselInStation;
	static double totalPriceGasoline;
	static double totalPriceDiesel;
	static boolean hasCoupon;
	static boolean discountedAntiFreeze;
	
public Station(String stationName, int ID, Gasoline[] gasolineArray, Diesel[] dieselArray, Service[] serviceArray) {
	
	this.stationName = stationName;
	this.ID = ID;
	this.dieselArray= new Diesel[10];
	this.gasolineArray = new Gasoline[10];
	this.serviceArray = new Service[10];
}
		
public static Station createStation() {
	
	String Name = null;
	int Id = 0;
	
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the name of the Station: ");
	Name = scanner.nextLine();
		
	System.out.printf("%s","Please enter the Station ID: ");
	Id = scanner.nextInt();
	
	return new Station(Name,Id, null, null, null);	
}

public Integer getID() {
	
	return ID;
}

public static void findStationAndAddGasoline(Station[] stationArray) {
	
	int givenId;
	int brace = 0;
	
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to search: ");
	givenId = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenId)) {
			stationArray[i].gasolineArray[stationArray[i].gasoline] = new Gasoline();
			
					totalGasolineInStation +=stationArray[i].gasolineArray[stationArray[i].gasoline].totalLiters; 
					totalPriceGasoline += stationArray[i].gasolineArray[stationArray[i].gasoline].totalLiters * stationArray[i].gasolineArray[stationArray[i].gasoline].pricePerLiter;
					averageGasolinePrice = totalPriceGasoline/totalGasolineInStation;

			
			System.out.println();
			brace = 1;
			stationArray[i].gasoline++;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			break;
			}		
	}
	System.out.println("The total gasoline liters in Station #" + givenId + " is " + totalGasolineInStation);
	System.out.println("The average gasoline price in Station #" + givenId + " is "+ averageGasolinePrice );
	
}

public static void findStationAndAddDiesel(Station[] stationArray){
	
	    
	int givenIdForDiesel;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to search: ");
	givenIdForDiesel = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDiesel)) {
			stationArray[i].dieselArray[stationArray[i].diesel] = new Diesel();
			
				totalDieselInStation +=stationArray[i].dieselArray[stationArray[i].diesel].totalLiters; 
				totalPriceDiesel += stationArray[i].dieselArray[stationArray[i].diesel].totalLiters * stationArray[i].dieselArray[stationArray[i].diesel].pricePerLiter;
				averageDieselPrice = totalPriceDiesel/totalDieselInStation;
			
			System.out.println();
			brace = 1;
			stationArray[i].diesel++;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			break;
			}
	}
	
	System.out.println("The total diesel liters in Station #" + givenIdForDiesel + " is " + totalDieselInStation);
	System.out.println("The average diesel price in Station #" + givenIdForDiesel + " is "+ averageDieselPrice );
}

public static void displayStationInventory(Station[] stationArray) {
	
	int givenIdForDisplay;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to display: ");
	givenIdForDisplay = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDisplay)) {
			System.out.println("Displaying the inventory of Station #"+ givenIdForDisplay);
			System.out.println();
			
			for(Gasoline g : stationArray[i].gasolineArray) {
				
				if(g != null) {
					g.displayGasoline();
					System.out.println();
				}
			}
			
			System.out.println("The total gasoline liters in Station #" + givenIdForDisplay + " is " + totalGasolineInStation);
			System.out.println("The average gasoline price in Station #" + givenIdForDisplay + " is "+ averageGasolinePrice );
			System.out.println();
			
			for(Diesel d : stationArray[i].dieselArray) {
				
				if(d != null) {
					d.displayDiesel();
					System.out.println();
				}
			}
			
			System.out.println("The total diesel liters in Station #" + givenIdForDisplay + " is " + totalDieselInStation);
			System.out.println("The average diesel price in Station #" + givenIdForDisplay + " is "+ averageDieselPrice );
			brace = 1;
			break;
		}
	}
		if (brace == 0) {
			System.out.println("No station found with the given ID!");
	}
}

public static void sellGasoline(Station[] stationArray) {
	
	int givenId;
	int brace = 0;
	String carPlate = null;
	double literBought = 0;
	boolean hasCoupon = false;
	String coupon;
	
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to sell Gasoline: ");
	givenId = scanner.nextInt();
	scanner.nextLine();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenId)) {
			
			System.out.printf("%s","Please enter the car plate: ");
			carPlate = scanner.nextLine();
				
			System.out.printf("%s","Please enter the gasoline liter: ");
			literBought = scanner.nextDouble();
			scanner.nextLine();
			
			if(literBought <= totalGasolineInStation) {
			
				System.out.printf("%s","Please enter if you have a coupon (y/n): ");
				coupon = scanner.nextLine();
			
				if (coupon.equals("y")) {
					hasCoupon = true;
				}
			
				if (coupon.equals("n")) {
					hasCoupon = false;
				}	
				
				totalGasolineInStation = totalGasolineInStation - literBought;
				
				GasolineService g = new GasolineService(carPlate,literBought,hasCoupon);
				g.makeTransaction(stationArray[i].averageGasolinePrice);
				
				stationArray[i].serviceArray[stationArray[i].serviceG++] = g;
				
			}else {
				System.out.println("Not enough gasoline in the station!");
			}
				
			System.out.println();
		    brace = 1;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");	
			break;
		}
	}	
}

public static void sellDiesel(Station[] stationArray) {
	
	int givenIdForDiesel;
	int brace = 0;
	String carPlate = null;
	double literBought = 0;
	String coupon;
	boolean hasCoupon = false;
	boolean discountedAntiFreeze = false;
	double discountAntiFreezePrice = 25.0;
	int discountedAntiFreezeCount = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to sell Diesel: ");
	givenIdForDiesel = scanner.nextInt();
	scanner.nextLine();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDiesel)) {
			
			System.out.printf("%s","Please enter the car plate: ");
			carPlate = scanner.nextLine();
				
			System.out.printf("%s","Please enter the diesel liter: ");
			literBought = scanner.nextDouble();
			scanner.nextLine();
			
			
			if(literBought <= totalDieselInStation) {
			
				System.out.printf("%s","Please enter if you have a coupon (y/n): ");
				coupon = scanner.nextLine();
			
				if (coupon.equals("y")) {
					hasCoupon = true;
				}
			
				if (coupon.equals("n")) {
					hasCoupon = false;
				}	
				
				totalDieselInStation = totalDieselInStation - literBought;
				
				System.out.printf("%s","Please enter how many anti-freeze you want: ");
				discountedAntiFreezeCount = scanner.nextInt();
				scanner.nextLine();
				
				if(discountedAntiFreezeCount > 0){
					discountedAntiFreeze = true;
				}else{
					discountedAntiFreeze = false;
				}

				DieselService d = new DieselService(carPlate,literBought,hasCoupon,discountedAntiFreezeCount,discountAntiFreezePrice);
				d.makeTransaction(stationArray[i].averageDieselPrice);
				
				stationArray[i].serviceArray[stationArray[i].serviceG++] = d;
				
			}else {
				System.out.println("Not enough diesel in the station!");
			}
				
			System.out.println();
		    brace = 1;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");	
			break;
		}
	}	
}

public static void displayServices(Station[] stationArray) {

	int givenIdForDisplay;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to display: ");
	givenIdForDisplay = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDisplay)) {
			System.out.println("Displaying the sold services of Station #"+ givenIdForDisplay);
			
			for(Service s : stationArray[i].serviceArray) {
				
				if(s != null) {
					s.displayServiceInfo();
				}
			}
			
			System.out.println();
			brace = 1;
			break;
		}
	}
		if (brace == 0) {
			System.out.println("No station found with the given ID!");
		}
	}


}
