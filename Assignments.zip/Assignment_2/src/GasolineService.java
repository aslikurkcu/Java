
public class GasolineService extends FuelService {
	
	static boolean hasCoupon;
	
	GasolineService(String carPlate, double literBought, boolean hasCoupon){
		
		super(carPlate,literBought);
		this.hasCoupon = hasCoupon;	
	}
	
	public void displayServiceInfo() {
		
		System.out.println();
		System.out.println("Gasoline Service...");
		super.displayServiceInfo();
		
		if (hasCoupon == true) {
			
		System.out.println("Has 10% discount coupon" );
		}
	}
	
	public double makeTransaction(double avarageGasolinePrice) {
		
		double total = 0.0;
		if (hasCoupon == true) {
			total = (avarageGasolinePrice * literBought )* 0.9 ;
		}else {
			total = avarageGasolinePrice * literBought;
		}
		super.makeTransaction(total);
		return 0;	
	}
}
