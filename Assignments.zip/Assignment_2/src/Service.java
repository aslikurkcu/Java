
public class Service {
	String carPlate;
	double revenue;
	
	Service(String carPlate){
		this.carPlate = carPlate;
		this.revenue = revenue;
	}	
		
	public void displayServiceInfo(){
		
		System.out.println("Car Plate is " + carPlate + " .");
		System.out.println("The revenue from this service " + revenue + " .");
	}	
	
	public double makeTransaction(double price){
		revenue = price;		
		return 0;	
	}
}
