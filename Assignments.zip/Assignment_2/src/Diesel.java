import java.util.Scanner;

public class Diesel {
	String origin;
	double pricePerLiter;
	double totalLiters;
	
	public Diesel() 
	{
		Scanner myscanner = new Scanner(System.in);
		System.out.printf("%s","Please enter the origin of Diesel: ");
		origin = myscanner.next();
		
		System.out.printf("%s","Please enter the price per liter: ");
		pricePerLiter = myscanner.nextDouble();
		
		System.out.printf("%s","Please enter the total shipment volume in liter: ");
		totalLiters = myscanner.nextDouble();
	}
	
public void displayDiesel() {
	
	System.out.println("Diesel...");
	System.out.println("The origin is: " + origin);
	System.out.println("Price per liter is: " + pricePerLiter );
	System.out.println("Total liters of this diesel is: " + totalLiters);
}
}