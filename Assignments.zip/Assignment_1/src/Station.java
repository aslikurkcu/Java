import java.util.Scanner;

public class Station {
	private String stationName;
	private int ID;
	Gasoline[] gasolineArray;
	Diesel[] dieselArray;
	int gasoline = 0;
	int diesel = 0; 
	int station = 0;
	
	
public Station(String stationName, int ID, Gasoline[] gasolineArray, Diesel[] dieselArray) {
	
	this.stationName = stationName;
	this.ID = ID;
	this.dieselArray= new Diesel[10];
	this.gasolineArray = new Gasoline[10];
}
		

public static Station createStation() {
	
	String Name = null;
	int Id = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the name of the Station: ");
	Name = scanner.nextLine();
		
	System.out.printf("%s","Please enter the Station ID: ");
	Id = scanner.nextInt();
	scanner.nextLine();
	
	return new Station(Name,Id, null, null);	
}


public int getID() {
	
	return this.ID;
}


public static void findStationAndAddGasoline(Station[] stationArray) {
	
	int givenId;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to search: ");
	givenId = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		if(stationArray[i]!= null && (stationArray[i].getID() == givenId)) {
			stationArray[i].gasolineArray[stationArray[i].gasoline++] = new Gasoline();
			System.out.println();
			brace = 1;
			break;
		}
	}
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			
			
		}
	}



public static void findStationAndAddDiesel(Station[] stationArray){
	
	    
	int givenIdForDiesel;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to search: ");
	givenIdForDiesel = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		if(stationArray[i]!= null && (stationArray[i].getID() == givenIdForDiesel) ){
			stationArray[i].dieselArray[stationArray[i].diesel++] = new Diesel();
			System.out.println();
			brace = 1;
			break;
		}
	}
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			
			
	}
}

public static void displayStationInventory(Station[] stationArray) {
	
	int givenIdForDisplay;
	int flag = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to display: ");
	givenIdForDisplay = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		if(stationArray[i]!= null && (stationArray[i].getID()==givenIdForDisplay)) {
			System.out.println("Displaying the inventory of Station #"+ givenIdForDisplay);
			
			for(Gasoline g : stationArray[i].gasolineArray) {
				
				if(g != null) {
					g.displayGasoline();
				}
			}
			System.out.println();
			for(Diesel d : stationArray[i].dieselArray) {
				
				if(d != null) {
					d.displayGasoline();
				}
			}
			
			System.out.println();
			flag = 1;
			break;
		}
		}
		if (flag == 0) {
		
			System.out.println("No station found with the given ID!");
	}
}

}

