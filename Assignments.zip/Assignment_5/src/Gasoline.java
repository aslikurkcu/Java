import java.util.InputMismatchException;
import java.util.Scanner;

public class Gasoline {
	
	private String origin;
	private double pricePerLiter;
	private double totalLiters;
	boolean perLiterLoop = true;
	boolean totalLiterLoop = true;
	
	public Gasoline() 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.printf("%s","Please enter the origin of gasoline: ");
	    origin = scanner.nextLine();
		
		while(perLiterLoop){
			
			try {
				Scanner myScanner = new Scanner(System.in);
				System.out.printf("%s","Please enter the price per liter: ");
				setPricePerLiter(myScanner.nextDouble());
				myScanner.nextLine();
				perLiterLoop = false;
				
			}catch(InputMismatchException idMissmatch) {
				
				System.err.print("price should be a double...\n");
			}
		}
		
		perLiterLoop = true;
		
		while(totalLiterLoop){
			
			try {
				Scanner myScanner = new Scanner(System.in);
				System.out.printf("%s","Please enter the total shipment volume in liter: ");
				setTotalLiters(myScanner.nextDouble());
				myScanner.nextLine();
				totalLiterLoop = false;
				
			}catch(InputMismatchException idMissmatch) {
				
				System.err.print("total liters should be a double...\n");
			}
		}
		
		totalLiterLoop = true;
	}			
	
public void displayGasoline() {
	
	System.out.println("Gasoline...");
	System.out.println("The origin is: " + origin);
	System.out.println("Price per liter is: " + getPricePerLiter() );
	System.out.println("Total liters of this gasoline is: " + getTotalLiters());
}

public double getTotalLiters() {
	return totalLiters;
}

public void setTotalLiters(double totalLiters) {
	this.totalLiters = totalLiters;
}

public double getPricePerLiter() {
	return pricePerLiter;
}

public void setPricePerLiter(double pricePerLiter) {
	this.pricePerLiter = pricePerLiter;
}

}