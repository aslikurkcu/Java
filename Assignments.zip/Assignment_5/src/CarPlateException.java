
public class CarPlateException extends Exception {
	
	public CarPlateException(String exceptionMessage) {
		
	super(exceptionMessage);
	
	}

}
