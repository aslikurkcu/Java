import java.util.InputMismatchException;
import java.util.Scanner;

public class Diesel {
	
	private String origin;
	private double pricePerLiter;
	private double totalLiters;
	boolean perLiterLoop = true;
	boolean totalLiterLoop = true;
	
	public Diesel() 
	{
		Scanner myscanner = new Scanner(System.in);
		System.out.printf("%s","Please enter the origin of Diesel: ");
		origin = myscanner.next();
		
		while(perLiterLoop){
			
			try {
				Scanner scanner = new Scanner(System.in);
				System.out.printf("%s","Please enter the price per liter: ");
				setPricePerLiter(scanner.nextDouble());
				scanner.nextLine();
				perLiterLoop = false;
				
			}catch(InputMismatchException idMissmatch) {
				
				System.err.print("price should be a double...\n");
			}
		}
		
		perLiterLoop = true;
		
		while(totalLiterLoop){
			
			try {
				Scanner sc = new Scanner(System.in);
				System.out.printf("%s","Please enter the total shipment volume in liter: ");
				setTotalLiters(sc.nextDouble());
				sc.nextLine();
				totalLiterLoop = false;
				
			}catch(InputMismatchException idMissmatch) {
				
				System.err.print("total liters should be a double...\n");
			}
		}
		
		totalLiterLoop = true;
		
	}
	
public void displayDiesel() {
	
	System.out.println("Diesel...");
	System.out.println("The origin is: " + origin);
	System.out.println("Price per liter is: " + getPricePerLiter() );
	System.out.println("Total liters of this diesel is: " + getTotalLiters());
}

public double getTotalLiters() {
	return totalLiters;
}

public void setTotalLiters(double totalLiters) {
	this.totalLiters = totalLiters;
}

public double getPricePerLiter() {
	return pricePerLiter;
}

public void setPricePerLiter(double pricePerLiter) {
	this.pricePerLiter = pricePerLiter;
}

}
