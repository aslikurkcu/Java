
import java.util.*;


public class Station {
	
	private String stationName;
	private int ID;
	Gasoline[] gasolineArray;
	Diesel[] dieselArray;
	private int gasoline = 0;
	private int diesel = 0; 
	private int serviceG = 0;
	Service[] serviceArray;
	private double averageGasolinePrice;
	private double totalGasolineInStation;
	private double averageDieselPrice;
	private double totalDieselInStation;
	private double totalPriceGasoline;
	private double totalPriceDiesel;
	private boolean hasCoupon;
	private static boolean discountedAntiFreeze;
	final static double basePrice = 10.0;
	ArrayList<Person> personList = new ArrayList<Person>();
	ArrayList<Profitable> profitList = new ArrayList<Profitable>();
	ArrayList<Service> serviceList = new ArrayList<Service>();
	
public Station(String stationName, int ID, Gasoline[] gasolineArray, Diesel[] dieselArray, Service[] serviceArray) {
	
	this.stationName = stationName;
	this.ID = ID;
	this.dieselArray= new Diesel[10];
	this.gasolineArray = new Gasoline[10];
	this.serviceArray = new Service[10];
}
		
public static Station createStation() {
	
	String Name = null;
	int Id = 0;
	boolean idLoop = true;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the name of the Station: ");
	Name = scanner.nextLine();
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the Station ID: ");
			Id = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	return new Station(Name,Id, null, null, null);	
}

public Integer getID() {
	return ID;
}

public static void findStationAndAddGasoline(Station[] stationArray) {
	
	int givenId = 0;
	int brace = 0;
	boolean idLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to search: ");
			givenId = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenId ) {
			stationArray[i].gasolineArray[stationArray[i].gasoline] = new Gasoline();
			
				stationArray[i].totalGasolineInStation +=stationArray[i].gasolineArray[stationArray[i].gasoline].getTotalLiters(); 
				stationArray[i].totalPriceGasoline += stationArray[i].gasolineArray[stationArray[i].gasoline].getTotalLiters() * stationArray[i].gasolineArray[stationArray[i].gasoline].getPricePerLiter();
				stationArray[i].averageGasolinePrice = stationArray[i].totalPriceGasoline/stationArray[i].totalGasolineInStation;
					
				System.out.println();
				System.out.println("The total gasoline liters in Station #" + givenId + " is " + stationArray[i].totalGasolineInStation);
				System.out.println("The average gasoline price in Station #" + givenId + " is "+ stationArray[i].averageGasolinePrice );
					
			brace = 1;
			stationArray[i].gasoline++;
			break;
		}
	}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
					
		}
}

public static void findStationAndAddDiesel(Station[] stationArray){
	    
	int givenIdForDiesel =0;
	int brace = 0;
	boolean idLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to search: ");
			givenIdForDiesel = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenIdForDiesel) {
			stationArray[i].dieselArray[stationArray[i].diesel] = new Diesel();
			
				stationArray[i].totalDieselInStation +=stationArray[i].dieselArray[stationArray[i].diesel].getTotalLiters(); 
				stationArray[i].totalPriceDiesel += stationArray[i].dieselArray[stationArray[i].diesel].getTotalLiters() * stationArray[i].dieselArray[stationArray[i].diesel].getPricePerLiter();
				stationArray[i].averageDieselPrice = stationArray[i].totalPriceDiesel/stationArray[i].totalDieselInStation;
				
				System.out.println();
				System.out.println("The total diesel liters in Station #" + givenIdForDiesel + " is " + stationArray[i].totalDieselInStation);
				System.out.println("The average diesel price in Station #" + givenIdForDiesel + " is "+ stationArray[i].averageDieselPrice );
				
			brace = 1;
			stationArray[i].diesel++;
			break;
		}
		
	}
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			
		}
}

public static void displayStationInventory(Station[] stationArray) {
	
	int givenIdForDisplay = 0;
	int brace = 0;
	boolean idLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to search: ");
			givenIdForDisplay = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenIdForDisplay) {
			System.out.println("Displaying the inventory of Station #"+ givenIdForDisplay);
			System.out.println();
			
			for(Gasoline g : stationArray[i].gasolineArray) {
				
				if(g != null) {
					g.displayGasoline();
					System.out.println();
				}
			}	
			System.out.println("The total gasoline liters in Station #" + givenIdForDisplay + " is " + stationArray[i].totalGasolineInStation);
			System.out.println("The average gasoline price in Station #" + givenIdForDisplay + " is "+ stationArray[i].averageGasolinePrice );
			System.out.println();
			
			for(Diesel d : stationArray[i].dieselArray) {
				
				if(d != null) {
					d.displayDiesel();
					System.out.println();
				}
			}	
			System.out.println("The total diesel liters in Station #" + givenIdForDisplay + " is " + stationArray[i].totalDieselInStation);
			System.out.println("The average diesel price in Station #" + givenIdForDisplay + " is "+ stationArray[i].averageDieselPrice );
			brace = 1;
			break;
		}
	}
		if (brace == 0) 
			System.out.println("No station found with the given ID!");
}

public static void sellGasoline(Station[] stationArray) throws CarPlateException {
	
	int givenId = 0;
	int brace = 0;
	String carPlate = null;
	double literBought = 0;
	boolean hasCoupon = false;
	String coupon;
	boolean idLoop = true;
	boolean literBoughtLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to sell Gasoline: ");
			givenId = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenId) {
			
			authenticateCarPlate();
			
			while(literBoughtLoop){
				
				try {
					Scanner myScanner = new Scanner(System.in);
					System.out.printf("%s","Please enter the gasoline liter: ");
					literBought = myScanner.nextDouble();
					myScanner.nextLine();
					literBoughtLoop = false;
					
				}catch(InputMismatchException literMissmatch) {
					
					System.err.print("gasoline liter should be a double...\n");
				}
			}
			
			literBoughtLoop = true;
			
			if(literBought <= stationArray[i].totalGasolineInStation) {
			
				Scanner scanner = new Scanner(System.in);
				System.out.printf("%s","Please enter if you have a coupon (y/n): ");
				coupon = scanner.nextLine();
			
				if (coupon.equals("y")|| coupon.equals("Y")) 
					hasCoupon = true;
				
				if (coupon.equals("n")|| coupon.equals("N")) 
					hasCoupon = false;
					
				stationArray[i].totalGasolineInStation = stationArray[i].totalGasolineInStation - literBought;
				
				GasolineService g = new GasolineService(carPlate,literBought,hasCoupon);
				g.makeTransaction(stationArray[i].averageGasolinePrice);
				
				stationArray[i].serviceArray[stationArray[i].serviceG++] = g;
				stationArray[i].profitList.add(g);
				stationArray[i].serviceList.add(g);
				
				System.out.println("Personnel that helped during this service:");
				int num = (int) (Math.random() * stationArray[i].personList.size());
				stationArray[i].personList.get(num).displayInformation();
				stationArray[i].personList.get(num).getJobCounter();
				
			}else {
				System.out.println("Not enough gasoline in the station!");
			}
				
		    brace = 1;
			break;
		}
	}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");	
		}	
}

public static void sellDiesel(Station[] stationArray) throws CarPlateException {
	
	int givenIdForDiesel = 0;
	int brace = 0;
	String carPlate = null;
	double literBought = 0;
	String coupon;
	boolean hasCoupon = false;
	double discountAntiFreezePrice = 25.0;
	int discountedAntiFreezeCount = 0;
	boolean idLoop = true;
	boolean antiFreezeLoop = true;
	boolean literBoughtLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to sell Diesel: ");
			givenIdForDiesel = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenIdForDiesel) {
			
			authenticateCarPlate();

			while(literBoughtLoop){
				
				try {
					Scanner myScanner = new Scanner(System.in);
					System.out.printf("%s","Please enter the diesel liter: ");
					literBought = myScanner.nextDouble();
					myScanner.nextLine();
					literBoughtLoop = false;
					
				}catch(InputMismatchException literMissmatch) {
					
					System.err.print("diesel liter should be a double...\n");
				}
			}
			
			literBoughtLoop = true;
		
			if(literBought <= stationArray[i].totalDieselInStation) {
				
				Scanner scanner = new Scanner (System.in);
				System.out.printf("%s","Please enter if you have a coupon (y/n): ");
				coupon = scanner.nextLine();
			
				if (coupon.equals("y") || coupon.equals("Y") ) {
					hasCoupon = true;
					
					while(antiFreezeLoop){
						
						try {
							Scanner myScanner = new Scanner(System.in);
							System.out.printf("%s","Please enter how many anti-freeze you want: ");
							discountedAntiFreezeCount = myScanner.nextInt();
							myScanner.nextLine();
							antiFreezeLoop = false;
							
						}catch(InputMismatchException antifreezeMissmatch) {
							
							System.err.print("anti-freeze count should be an integer...\n");
						}
					}
					
					antiFreezeLoop = true;
				
				}
			
				if (coupon.equals("n")|| coupon.equals("N")) {
					hasCoupon = false;
				}	
				
				stationArray[i].totalDieselInStation = stationArray[i].totalDieselInStation - literBought;
				
				
				if(discountedAntiFreezeCount > 0){
					discountedAntiFreeze = true;
				}else{
					discountedAntiFreeze = false;
				}

				DieselService d = new DieselService(carPlate,literBought,hasCoupon,discountedAntiFreezeCount,discountAntiFreezePrice);
				d.makeTransaction(stationArray[i].averageDieselPrice);
				
				stationArray[i].serviceArray[stationArray[i].serviceG++] = d;
				stationArray[i].profitList.add(d);
				stationArray[i].serviceList.add(d);
				
				System.out.println("Personnel that helped during this service:");
				int num = (int) (Math.random() * stationArray[i].personList.size());
				stationArray[i].personList.get(num).displayInformation();
				stationArray[i].personList.get(num).getJobCounter();
				
			}else {
				System.out.println("Not enough diesel in the station!");
			}
				
		    brace = 1;
			break;
		}
	}	
		if(brace == 0) {
			System.out.println("No station found with the given ID!");	
		}	
}

public static void displayServices(Station[] stationArray) {

	int givenIdForDisplay = 0;
	int brace = 0;
	boolean idLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to display: ");
			givenIdForDisplay = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenIdForDisplay) {
			System.out.println("Displaying the sold services of Station #"+ givenIdForDisplay);
			
			Collections.sort(stationArray[i].serviceList);
			
			for(Service s : stationArray[i].serviceList) {
				
				if(s != null) {
					
					s.displayServiceInfo();
				}
			}
			brace = 1;
			break;
		}
	}
		if (brace == 0) 
			System.out.println("No station found with the given ID!");	
}

public static void sellCarWash(Station[] stationArray) throws CarPlateException {
	
	int givenIdForWash = 0;
	int brace = 0;
	String carPlate = null;
	boolean idLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to sell car wash: ");
			givenIdForWash = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForWash)) {
			
			authenticateCarPlate();
			
			System.out.println("Personnel that helped during this service:");
			int num = (int) (Math.random() * stationArray[i].personList.size());
			stationArray[i].personList.get(num).displayInformation();
			stationArray[i].personList.get(num).getJobCounter();
			
			CarWash c = new CarWash(carPlate);
			stationArray[i].serviceArray[stationArray[i].serviceG++]= c;	
			stationArray[i].profitList.add(c);
			stationArray[i].serviceList.add(c);
			c.makeTransaction(basePrice);
			
			brace = 1;
			break;
		}
		
	}
		if(brace == 0) {
			System.out.println("No station found with the given ID!");			
		}
}

public static void addPerson(Station[] stationArray) {

	String input = null;
	String name = null;
	String surname = null;
	int givenIdForPerson = 0;
	int workYear = 0;
	int brace = 0;
	boolean idLoop = true;
	boolean workYearLoop = true;
	
	System.out.println("1. Add a personnel");
	System.out.println("2. Add a manager");
	
	Scanner scanner = new Scanner(System.in);
	input = scanner.nextLine();
	System.out.println();
	
	if (input.equals("1")) {
			
		while(idLoop){
			
			try {
				Scanner myScanner = new Scanner(System.in);
				System.out.printf("%s","Please enter the ID of the Station you want to add a person: ");
				givenIdForPerson = myScanner.nextInt();
				myScanner.nextLine();
				idLoop = false;
				System.out.println();
				
			}catch(InputMismatchException idMissmatch) {
				
				System.err.print("ID should be an integer...\n");
			}
		}
		
		for(int i=0; i<10; i++) {
			
			if(stationArray[i]!= null && (stationArray[i].getID() == givenIdForPerson)) {
				
				System.out.printf("%s","Please enter a name: ");
				name = scanner.nextLine();
				System.out.printf("%s","Please enter a surname: ");
				surname = scanner.nextLine();
				
				Person p = new Personnel (name,surname);
				stationArray[i].personList.add(p);	
				stationArray[i].profitList.add(p);
				
				brace = 1;
				break;
			}
		}
			if(brace == 0) {
				System.out.println("No station found with the given ID!");
		
			}
		
	}else if (input.equals("2")) {
		
		while(idLoop){
			
			try {
				Scanner myScanner = new Scanner(System.in);
				System.out.printf("%s","Please enter the ID of the Station you want to add a person: ");
				givenIdForPerson = myScanner.nextInt();
				myScanner.nextLine();
				idLoop = false;
				System.out.println();
				
			}catch(InputMismatchException idMissmatch) {
				
				System.err.print("ID should be an integer...\n");
			}
		}
		
		for(int i=0; i<10; i++) {
					
			if(stationArray[i]!= null && (stationArray[i].getID() == givenIdForPerson)) {
						
				System.out.printf("%s","Please enter a name: ");
				name = scanner.nextLine();
				System.out.printf("%s","Please enter a surname: ");
				surname = scanner.nextLine();
				
				while(workYearLoop){
					
					try {
						Scanner myScanner = new Scanner(System.in);
						System.out.printf("%s","Please enter how many years the manager is working: ");
						workYear = myScanner.nextInt();
						myScanner.nextLine();
						workYearLoop = false;
						
					}catch(InputMismatchException workYearMissmatch) {
						
						System.err.print("work year should be an integer...\n");
					}
				}
				
				workYearLoop = true;
			
				Person p = new Manager (name,surname,workYear);
				stationArray[i].personList.add(p);	
				stationArray[i].profitList.add(p);	
						
				brace = 1;
					break;
				}
		}
					
				if(brace == 0) {
					System.out.println("No station found with the given ID!");	
				}	
	}		
}

public static void calculateNetProfit(Station[] stationArray) {
	
	int givenIdForProfit = 0;
	int brace = 0;
	double total = 0;
	double temporary;
	boolean idLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to calculate profit: ");
			givenIdForProfit = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenIdForProfit) {
			
			Iterator <Profitable> itr = stationArray[i].profitList.iterator();
			
			while(itr.hasNext()) {
				
				Profitable profit = (Profitable)itr.next();			
				temporary = profit.calculate();
				total += temporary;			
				System.out.println(temporary);	
			}
			
			System.out.println("Net profit of station is: "+ total);
			
			brace = 1;
			break;
		}
	}
		if (brace == 0) 
			System.out.println("No station found with the given ID!");
}	

public static void displayServices2(Station[] stationArray) {
	
	int givenIdForDisplay = 0;
	int brace = 0;
	boolean idLoop = true;
	
	while(idLoop){
		
		try {
			Scanner myScanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the ID of the Station you want to display: ");
			givenIdForDisplay = myScanner.nextInt();
			myScanner.nextLine();
			idLoop = false;
			System.out.println();
			
		}catch(InputMismatchException idMissmatch) {
			
			System.err.print("ID should be an integer...\n");
		}
	}
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()) == givenIdForDisplay) {
			System.out.println("Displaying the sold services of Station #"+ givenIdForDisplay);
			
			CarPlateCompare plateCompare = new CarPlateCompare();
			Collections.sort(stationArray[i].serviceList,plateCompare);
			
			for(Service s : stationArray[i].serviceList) {
				
				if(s != null) {
					s.displayServiceInfo();
				}
			}
			brace = 1;
			break;
		}
	}
		if (brace == 0) 
			System.out.println("No station found with the given ID!");
	
}

public static void authenticateCarPlate() throws CarPlateException{
	
	String x = null; // car plate format >> int a + Sting x + int b 
	int flag = 0;
	int a = 0;
	int b = 0;
	String carPlate = null;
	Character letters[] ={'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'V', 'Y', 'Z'};
	boolean carPlateLoop = true;
	boolean contains = false;
	int flag1 = 0;
	int flag2 = 0;
	int flag3= 0;
	
	while(carPlateLoop) {
		
		try {
		
			Scanner scanner = new Scanner(System.in);
			System.out.printf("%s","Please enter the car plate: ");
			a = scanner.nextInt();
			x = scanner.next();
			b = scanner.nextInt(); 
			
			if (a >= 1 && a <= 81 ) {
				
				if (x.length() == 1) {
					
					if( b >= 1000 && b <=99999 ) {
						
						for (char c: letters) {
							if(x.charAt(0) == c) {
								contains = true;
							}
						}
						
						carPlate = a + " " + x + " " + b;
						
					}else{ throw new CarPlateException("Please enter a valid Car Plate...\n"); }
						
					
				}else if(x.length() == 2) {
					
					if( b >= 10 && b <=9999 ) {
						
						for (char c: letters) {
							if(x.charAt(0) == c) {
								flag1 = 1;
							}
						}
						for (char c: letters) {
							if(x.charAt(1) == c) {
								flag2 = 1;
							}
						}
						if (flag1 == 1 && flag2 == 1) {
							contains = true;
						}
					
						carPlate = a + " " + x + " " + b;
						
					}else{ throw new CarPlateException("Please enter a valid Car Plate...\n"); }
					
				}else if (x.length() == 3) {
					
					if( b >= 10 && b <=999 ) {
						
						for (char c: letters) {
							if(x.charAt(0) == c) {
								flag1 = 1;
							}
						}
						for (char c: letters) {
							if(x.charAt(1) == c) {
								flag2 = 1;
							}
						}
						for (char c: letters) {
							if(x.charAt(2) == c) {
								flag3 = 1;
							}
						}
						if (flag1 == 1 && flag2 == 1 && flag3 == 1) {
							contains = true;
						}
						
						carPlate = a + " " + x + " " + b;
						
					}else{ throw new CarPlateException("Please enter a valid Car Plate...\n"); }
					
				}else { throw new CarPlateException("Please enter a valid Car Plate...\n"); }
				
			}else { throw new CarPlateException("Please enter a valid Car Plate...\n");}
			
			carPlateLoop = false;
			
		}catch (CarPlateException carPlateException) {
			
			System.err.print(carPlateException.getMessage());
			
		}		
	}
}

}
