import java.util.Scanner;

public class Gasoline {
	
	private String origin;
	private double pricePerLiter;
	private double totalLiters;
	
	public Gasoline() 
	{
		Scanner scanner = new Scanner(System.in);
		System.out.printf("%s","Please enter the origin of gasoline: ");
	    origin = scanner.next();
		
		System.out.printf("%s","Please enter the price per liter: ");
		setPricePerLiter(scanner.nextDouble());
		
		System.out.printf("%s","Please enter the total shipment volume in liter: ");
		setTotalLiters(scanner.nextDouble());	
	}
	
	
public void displayGasoline() {
	
	System.out.println("Gasoline...");
	System.out.println("The origin is: " + origin);
	System.out.println("Price per liter is: " + getPricePerLiter() );
	System.out.println("Total liters of this gasoline is: " + getTotalLiters());
}

public double getTotalLiters() {
	return totalLiters;
}

public void setTotalLiters(double totalLiters) {
	this.totalLiters = totalLiters;
}

public double getPricePerLiter() {
	return pricePerLiter;
}

public void setPricePerLiter(double pricePerLiter) {
	this.pricePerLiter = pricePerLiter;
}

}