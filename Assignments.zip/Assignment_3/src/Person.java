
public abstract class Person implements Profitable{
	
	private String name;
	private String surname;
	private double salary = 100;
	
	public Person(String name, String surname) {
	
		this.name = name;
		this.surname = surname;
	
	}

public String getName() {
	return name;
}

public String getSurname() {
	return surname;
}

public double getSalary() {
	return salary;
}
public void getJobCounter() {
	
}

public void setSalary(double salary) {
	this.salary = salary;
}

void displayInformation(){
	
	System.out.println("Name: " + getName());
	System.out.println("Surname: " + getSurname());
		
	}

}
