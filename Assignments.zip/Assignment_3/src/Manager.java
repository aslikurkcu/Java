
public class Manager extends Person{

	private int jobYear;	
	private double managerextra = 200;
	
	public Manager(String name, String surname,int jobYear) {
		super(name, surname);
		this.jobYear = jobYear;
		
	}

@Override
public double calculate() {
	
	setSalary(- (getSalary() + managerextra + jobYear * 50));

	System.out.printf("%s", "class Manager: ");	
	return getSalary();
}

}
