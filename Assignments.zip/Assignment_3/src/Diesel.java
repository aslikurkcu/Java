import java.util.Scanner;

public class Diesel {
	
	private String origin;
	private double pricePerLiter;
	private double totalLiters;
	
	public Diesel() 
	{
		Scanner myscanner = new Scanner(System.in);
		System.out.printf("%s","Please enter the origin of Diesel: ");
		origin = myscanner.next();
		
		System.out.printf("%s","Please enter the price per liter: ");
		setPricePerLiter(myscanner.nextDouble());
		
		System.out.printf("%s","Please enter the total shipment volume in liter: ");
		setTotalLiters(myscanner.nextDouble());
	}
	
public void displayDiesel() {
	
	System.out.println("Diesel...");
	System.out.println("The origin is: " + origin);
	System.out.println("Price per liter is: " + getPricePerLiter() );
	System.out.println("Total liters of this diesel is: " + getTotalLiters());
}

public double getTotalLiters() {
	return totalLiters;
}

public void setTotalLiters(double totalLiters) {
	this.totalLiters = totalLiters;
}

public double getPricePerLiter() {
	return pricePerLiter;
}

public void setPricePerLiter(double pricePerLiter) {
	this.pricePerLiter = pricePerLiter;
}
}