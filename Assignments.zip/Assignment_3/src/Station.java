
import java.util.*;

public class Station {
	
	private String stationName;
	private int ID;
	Gasoline[] gasolineArray;
	Diesel[] dieselArray;
	private int gasoline = 0;
	private int diesel = 0; 
	private int serviceG = 0;
	Service[] serviceArray;
	private double averageGasolinePrice;
	private double totalGasolineInStation;
	private double averageDieselPrice;
	private double totalDieselInStation;
	private double totalPriceGasoline;
	private double totalPriceDiesel;
	private boolean hasCoupon;
	private static boolean discountedAntiFreeze;
	final static double basePrice = 10.0;
	ArrayList<Person> personList = new ArrayList<Person>();
	ArrayList<Profitable> profitList = new ArrayList<Profitable>();
	
public Station(String stationName, int ID, Gasoline[] gasolineArray, Diesel[] dieselArray, Service[] serviceArray) {
	
	this.stationName = stationName;
	this.ID = ID;
	this.dieselArray= new Diesel[10];
	this.gasolineArray = new Gasoline[10];
	this.serviceArray = new Service[10];
}
		
public static Station createStation() {
	
	String Name = null;
	int Id = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the name of the Station: ");
	Name = scanner.nextLine();
		
	System.out.printf("%s","Please enter the Station ID: ");
	Id = scanner.nextInt();
	
	return new Station(Name,Id, null, null, null);	
}

public Integer getID() {
	return ID;
}

public static void findStationAndAddGasoline(Station[] stationArray) {
	
	int givenId;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to search: ");
	givenId = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenId)) {
			stationArray[i].gasolineArray[stationArray[i].gasoline] = new Gasoline();
			
				stationArray[i].totalGasolineInStation +=stationArray[i].gasolineArray[stationArray[i].gasoline].getTotalLiters(); 
				stationArray[i].totalPriceGasoline += stationArray[i].gasolineArray[stationArray[i].gasoline].getTotalLiters() * stationArray[i].gasolineArray[stationArray[i].gasoline].getPricePerLiter();
				stationArray[i].averageGasolinePrice = stationArray[i].totalPriceGasoline/stationArray[i].totalGasolineInStation;
					
				System.out.println();
				System.out.println("The total gasoline liters in Station #" + givenId + " is " + stationArray[i].totalGasolineInStation);
				System.out.println("The average gasoline price in Station #" + givenId + " is "+ stationArray[i].averageGasolinePrice );
					
			brace = 1;
			stationArray[i].gasoline++;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			break;
			}		
	}
}

public static void findStationAndAddDiesel(Station[] stationArray){
	    
	int givenIdForDiesel;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to search: ");
	givenIdForDiesel = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDiesel)) {
			stationArray[i].dieselArray[stationArray[i].diesel] = new Diesel();
			
				stationArray[i].totalDieselInStation +=stationArray[i].dieselArray[stationArray[i].diesel].getTotalLiters(); 
				stationArray[i].totalPriceDiesel += stationArray[i].dieselArray[stationArray[i].diesel].getTotalLiters() * stationArray[i].dieselArray[stationArray[i].diesel].getPricePerLiter();
				stationArray[i].averageDieselPrice = stationArray[i].totalPriceDiesel/stationArray[i].totalDieselInStation;
				
				System.out.println();
				System.out.println("The total diesel liters in Station #" + givenIdForDiesel + " is " + stationArray[i].totalDieselInStation);
				System.out.println("The average diesel price in Station #" + givenIdForDiesel + " is "+ stationArray[i].averageDieselPrice );
				
			brace = 1;
			stationArray[i].diesel++;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			break;
			}
	}
}

public static void displayStationInventory(Station[] stationArray) {
	
	int givenIdForDisplay;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to display: ");
	givenIdForDisplay = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDisplay)) {
			System.out.println("Displaying the inventory of Station #"+ givenIdForDisplay);
			System.out.println();
			
			for(Gasoline g : stationArray[i].gasolineArray) {
				
				if(g != null) {
					g.displayGasoline();
					System.out.println();
				}
			}	
			System.out.println("The total gasoline liters in Station #" + givenIdForDisplay + " is " + stationArray[i].totalGasolineInStation);
			System.out.println("The average gasoline price in Station #" + givenIdForDisplay + " is "+ stationArray[i].averageGasolinePrice );
			System.out.println();
			
			for(Diesel d : stationArray[i].dieselArray) {
				
				if(d != null) {
					d.displayDiesel();
					System.out.println();
				}
			}	
			System.out.println("The total diesel liters in Station #" + givenIdForDisplay + " is " + stationArray[i].totalDieselInStation);
			System.out.println("The average diesel price in Station #" + givenIdForDisplay + " is "+ stationArray[i].averageDieselPrice );
			brace = 1;
			break;
		}
	}
		if (brace == 0) 
			System.out.println("No station found with the given ID!");
}

public static void sellGasoline(Station[] stationArray) {
	
	int givenId;
	int brace = 0;
	String carPlate = null;
	double literBought = 0;
	boolean hasCoupon = false;
	String coupon;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to sell Gasoline: ");
	givenId = scanner.nextInt();
	scanner.nextLine();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenId)) {
			
			System.out.printf("%s","Please enter the car plate: ");
			carPlate = scanner.nextLine();
				
			System.out.printf("%s","Please enter the gasoline liter: ");
			literBought = scanner.nextDouble();
			scanner.nextLine();
			
			if(literBought <= stationArray[i].totalGasolineInStation) {
			
				System.out.printf("%s","Please enter if you have a coupon (y/n): ");
				coupon = scanner.nextLine();
			
				if (coupon.equals("y")) 
					hasCoupon = true;
				
				if (coupon.equals("n")) 
					hasCoupon = false;
					
				stationArray[i].totalGasolineInStation = stationArray[i].totalGasolineInStation - literBought;
				
				GasolineService g = new GasolineService(carPlate,literBought,hasCoupon);
				g.makeTransaction(stationArray[i].averageGasolinePrice);
				
				stationArray[i].serviceArray[stationArray[i].serviceG++] = g;
				stationArray[i].profitList.add(g);
				
				System.out.println("Personnel that helped during this service:");
				int num = (int) (Math.random() * stationArray[i].personList.size());
				stationArray[i].personList.get(num).displayInformation();
				stationArray[i].personList.get(num).getJobCounter();
				
			}else {
				System.out.println("Not enough gasoline in the station!");
			}
				
		    brace = 1;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");	
			break;
		}
	}	
}

public static void sellDiesel(Station[] stationArray) {
	
	int givenIdForDiesel;
	int brace = 0;
	String carPlate = null;
	double literBought = 0;
	String coupon;
	boolean hasCoupon = false;
	double discountAntiFreezePrice = 25.0;
	int discountedAntiFreezeCount = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to sell Diesel: ");
	givenIdForDiesel = scanner.nextInt();
	scanner.nextLine();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDiesel)) {
			
			System.out.printf("%s","Please enter the car plate: ");
			carPlate = scanner.nextLine();
				
			System.out.printf("%s","Please enter the diesel liter: ");
			literBought = scanner.nextDouble();
			scanner.nextLine();
			
			
			if(literBought <= stationArray[i].totalDieselInStation) {
			
				System.out.printf("%s","Please enter if you have a coupon (y/n): ");
				coupon = scanner.nextLine();
			
				if (coupon.equals("y")) {
					hasCoupon = true;
					System.out.printf("%s","Please enter how many anti-freeze you want: ");
					discountedAntiFreezeCount = scanner.nextInt();
					scanner.nextLine();
				}
			
				if (coupon.equals("n")) {
					hasCoupon = false;
				}	
				
				stationArray[i].totalDieselInStation = stationArray[i].totalDieselInStation - literBought;
				
				
				if(discountedAntiFreezeCount > 0){
					discountedAntiFreeze = true;
				}else{
					discountedAntiFreeze = false;
				}

				DieselService d = new DieselService(carPlate,literBought,hasCoupon,discountedAntiFreezeCount,discountAntiFreezePrice);
				d.makeTransaction(stationArray[i].averageDieselPrice);
				
				stationArray[i].serviceArray[stationArray[i].serviceG++] = d;
				stationArray[i].profitList.add(d);
				
				System.out.println("Personnel that helped during this service:");
				int num = (int) (Math.random() * stationArray[i].personList.size());
				stationArray[i].personList.get(num).displayInformation();
				stationArray[i].personList.get(num).getJobCounter();
				
			}else {
				System.out.println("Not enough diesel in the station!");
			}
				
		    brace = 1;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");	
			break;
		}
	}	
}

public static void displayServices(Station[] stationArray) {

	int givenIdForDisplay;
	int brace = 0;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to display: ");
	givenIdForDisplay = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForDisplay)) {
			System.out.println("Displaying the sold services of Station #"+ givenIdForDisplay);
			
			for(Service s : stationArray[i].serviceArray) {
				
				if(s != null) {
					s.displayServiceInfo();
				}
			}
			brace = 1;
			break;
		}
	}
		if (brace == 0) 
			System.out.println("No station found with the given ID!");	
}

public static void sellCarWash(Station[] stationArray) {
	
	int givenIdForWash;
	int brace = 0;
	String carPlate = null;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to sell car wash: ");
	givenIdForWash = scanner.nextInt();
	scanner.nextLine();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForWash)) {
			
			System.out.printf("%s","Please enter the car plate: ");
			carPlate = scanner.nextLine();
			
			System.out.println("Personnel that helped during this service:");
			int num = (int) (Math.random() * stationArray[i].personList.size());
			stationArray[i].personList.get(num).displayInformation();
			stationArray[i].personList.get(num).getJobCounter();
			
			CarWash c = new CarWash(carPlate);
			stationArray[i].serviceArray[stationArray[i].serviceG++]= c;	
			stationArray[i].profitList.add(c);
			c.makeTransaction(basePrice);
			
			brace = 1;
			break;
		}
		
		if(brace == 0) {
			System.out.println("No station found with the given ID!");
			break;
			}		
	}
}

public static void addPerson(Station[] stationArray) {

	String input = null;
	String name = null;
	String surname = null;
	int givenIdForPerson = 0;
	int workYear = 0;
	int brace = 0;
	
	System.out.println("1. Add a personnel");
	System.out.println("2. Add a manager");
	
	Scanner scanner = new Scanner(System.in);
	input = scanner.nextLine();
	System.out.println();
	
	if (input.equals("1")) {
		
		System.out.printf("%s","Please enter the ID of the station you want to add a person: ");
		givenIdForPerson = scanner.nextInt();
		scanner.nextLine();
		System.out.println();
		
		for(int i=0; i<10; i++) {
			
			if(stationArray[i]!= null && (stationArray[i].getID()== givenIdForPerson)) {
				
				System.out.printf("%s","Please enter a name: ");
				name = scanner.nextLine();
				System.out.printf("%s","Please enter a surname: ");
				surname = scanner.nextLine();
				
				Person p = new Personnel (name,surname);
				stationArray[i].personList.add(p);	
				stationArray[i].profitList.add(p);
				
				brace = 1;
				break;
			}
			
			if(brace == 0) {
				System.out.println("No station found with the given ID!");
				break;
				}	
		}
		
	}else if (input.equals("2")) {
				
		System.out.printf("%s","Please enter the ID of the station you want to add a person: ");
		givenIdForPerson = scanner.nextInt();
		scanner.nextLine();
		System.out.println();
				
		for(int i=0; i<10; i++) {
					
			if(stationArray[i]!= null && (stationArray[i].getID() == givenIdForPerson)) {
						
				System.out.printf("%s","Please enter a name: ");
				name = scanner.nextLine();
				System.out.printf("%s","Please enter a surname: ");
				surname = scanner.nextLine();
				System.out.printf("%s","Please enter how many years the manager is working: ");
				workYear = scanner.nextInt();
				scanner.nextLine();
						
				Person p = new Manager (name,surname,workYear);
				stationArray[i].personList.add(p);	
				stationArray[i].profitList.add(p);	
						
				brace = 1;
					break;
				}
					
				if(brace == 0) {
					System.out.println("No station found with the given ID!");
					break;
					}		
		}	
	}		
}

public static void calculateNetProfit(Station[] stationArray) {
	
	int givenIdForProfit;
	int brace = 0;
	double total = 0;
	double temporary;
	
	Scanner scanner = new Scanner(System.in);
	System.out.printf("%s","Please enter the ID of the Station you want to calculate profit: ");
	givenIdForProfit = scanner.nextInt();
	System.out.println();
	
	for(int i=0; i<10; i++) {
		
		if(stationArray[i]!= null && (stationArray[i].getID()).equals(givenIdForProfit)) {
			
			Iterator <Profitable> itr = stationArray[i].profitList.iterator();
			
			while(itr.hasNext()) {
				
				Profitable profit = (Profitable)itr.next();			
				temporary = profit.calculate();
				total += temporary;			
				System.out.println(temporary);	
			}
			
			System.out.println("Net profit of station is: "+ total);
			
			brace = 1;
			break;
		}
	}
		if (brace == 0) 
			System.out.println("No station found with the given ID!");
}	

}
