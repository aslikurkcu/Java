
public abstract class Service implements Profitable{
	
	private String carPlate;
	private double revenue;
	
	Service(String carPlate){
		this.carPlate = carPlate;
	}	
		
public String getCarPlate(){
	return carPlate;	
}

public double getRevenue(){
	return revenue;	
}

public void setRevenue(double a) {
	revenue = a;
}
	
public void displayServiceInfo(){
		
	System.out.println("Car Plate is " + carPlate + " .");
	System.out.println("The revenue from this service " + revenue + " .");
}	
	
public double makeTransaction(double price){
	revenue = price;		
	return 0;	
	}
}
