
public class DieselService extends FuelService {
	
	private static boolean discountedAntiFreeze;
	private int discountedAntiFreezeCount;
	private double discountedAntiFreezePrice = 25.0;
	
	DieselService(String carPlate, 
					double literBought,
					boolean discountedAntiFreeze,
					int discountedAntiFreezeCount,
					double discountedAntiFreezePrice){
		
		super(carPlate,literBought);
		this.discountedAntiFreeze = discountedAntiFreeze;
		this.discountedAntiFreezeCount = discountedAntiFreezeCount;
		this.discountedAntiFreezePrice = discountedAntiFreezePrice;
	}

@Override
public void displayServiceInfo() {
		
	System.out.println();
	System.out.println("Diesel Service...");
	super.displayServiceInfo();	
		
	if(discountedAntiFreeze == true) {
		System.out.println("Bought " + discountedAntiFreezeCount + " discounted anti-freeze.");
	}
}

@Override
public double makeTransaction(double avarageDieselPrice) {
	double total = 0.0;
		
	if(discountedAntiFreeze == true) {
		total = (avarageDieselPrice * getLiterBought()) + (discountedAntiFreezePrice * discountedAntiFreezeCount);
		
	}else {
		total = avarageDieselPrice * getLiterBought();
	}
		
	super.makeTransaction(total);	
	return 0;
}

@Override
public double calculate() {
		
	System.out.printf("%s","class DieselService ");
	
	return getRevenue();
	}
}
