
enum MenuItems {
	
	M1("1. Create a new station"),
	M2("2. Add gasoline to a statiton inventory"), 
	M3("3. Add diesel to a statiton inventory"), 
	M4("4. Display a station inventory"), 
	M5("5. Sell gasoline to customer"),
	M6("6. Sell diesel to customer"), 
	M7("7. Sell car wash"), 
	M8("8. Display sold services so far"), 
	M9("9. Add personnel/manager to a station"),
	M10("10. Calculate net profit of a station"), 
	M11("0. Exit");

	private String menu ;

	MenuItems(String m) {
		menu = m;
	}

	String getMenu() {
		return menu;
	}
	
	static void printMenu() {
		System.out.println(M1.getMenu());
		System.out.println(M2.getMenu());
		System.out.println(M3.getMenu());
		System.out.println(M4.getMenu());
		System.out.println(M5.getMenu());
		System.out.println(M6.getMenu());
		System.out.println(M7.getMenu());
		System.out.println(M8.getMenu());
		System.out.println(M9.getMenu());
		System.out.println(M10.getMenu());
		System.out.println(M11.getMenu());
		
	}
}

