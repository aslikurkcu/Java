
public class Personnel extends Person{
	
	private int jobCount = 0;

	public Personnel(String name, String surname) {
		super(name, surname);
	}

@Override
public double calculate() {
		
	setSalary( - (getSalary() + jobCount * 1.5));
		
	System.out.printf("%s", "class Personnel: ");
	return getSalary();
}
@Override
public void getJobCounter() {
	
	jobCount++;
}

}
