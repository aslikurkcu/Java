
public interface Profitable {
	
	double calculate();
}
