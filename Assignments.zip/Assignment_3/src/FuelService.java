
public abstract class FuelService extends Service{

	private double literBought;
	
	FuelService(String carPlate, double literBought){
		
		super(carPlate);
		this.setLiterBought(literBought);		
	}

@Override
public void displayServiceInfo() {
		
	System.out.println("Bought " + getLiterBought() + " liters.");
	super.displayServiceInfo();
}

@Override
public double makeTransaction(double price){
	super.makeTransaction(price);
	return 0;
}

public double getLiterBought() {
	return literBought;
}

public void setLiterBought(double literBought) {
	this.literBought = literBought;
}

}