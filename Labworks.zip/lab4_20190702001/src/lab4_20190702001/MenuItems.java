package lab4_20190702001;

enum MenuItems {
	
	M1("1.Create a student"), 
	M2("2.Create a MasterStudent"),
	M3("3.Create a PhDStudent"),
	M4("4.Display all students"),
	M5("5.Display the student count"),
	M6("6.Find and remove a student"),
	M7("0.Exit"),;

	private String menu ;

	MenuItems(String m) {
		menu = m;
	}

	String getMenu() {
		return menu;
	}
}