package lab4_20190702001;

public class Student{
	
	private String name;
	private String surname;
	private String id;
	String thesisName;
	int lectureHours;

	
public Student(String name,String surname,String id) {
	this.name = name;
	this.surname = surname;
	this.id = id;
}

public String getName() {
	return name;
}

public String getSurname() {
	return surname;
}

public String getId() {
	return id;
}

public void displayStudents(){
		
		System.out.println();
		System.out.println("Name: " + getName());
		System.out.println("Surname: " + getSurname());
		System.out.println("ID: " + getId());
		
}

}
