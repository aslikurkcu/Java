package lab5_20190702001;

public interface Cafeteria {
	void serveFood();

}
