package lab5_20190702001;

public class Personnel implements Cafeteria {
	
	private String name;
	private String surname;
	
public Personnel(String name,String surname) {
	this.name = name;
	this.surname = surname;	
	}
	
public String getName() {
	return name;
	}

public String getSurname() {
	return surname;
	}

@Override
public void serveFood() {

	System.out.println("Serving food for " + getName() + " " + getSurname() + ": Is a personnel, so food is served. ");
	
}

}
