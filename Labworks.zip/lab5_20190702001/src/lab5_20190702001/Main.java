package lab5_20190702001;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;
import java.util.Iterator;

public class Main{
	
public static void main(String[] args) {
		
		String name;
		String surname;
		String id;
		String thesisName;
		int lectureHours;
		String input;
		int studentCount = 0;
		boolean hasFoodPass = false;
		String foodPass;
		
		ArrayList<Student> StudentArrayList = new ArrayList<Student>();
		ArrayList<Cafeteria> cafeteria = new ArrayList<Cafeteria>();
		
		while(true) {
		
		System.out.println(MenuItems.M1.getMenu());
		System.out.println(MenuItems.M2.getMenu());
		System.out.println(MenuItems.M3.getMenu());
		System.out.println(MenuItems.M4.getMenu());
		System.out.println(MenuItems.M5.getMenu());
		System.out.println(MenuItems.M6.getMenu());
		System.out.println(MenuItems.M7.getMenu());
		System.out.println(MenuItems.M8.getMenu());
		System.out.println(MenuItems.M9.getMenu());
		
		
		Scanner myScanner = new Scanner(System.in);
		input = myScanner.nextLine();
		System.out.println();
		
		if(input.equals("1")){
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.nextLine();
			System.out.printf("%s","Surname: ");
			surname = sc.nextLine();
			System.out.printf("%s","ID: ");
			id = sc.nextLine();
			System.out.printf("%s","Does the student have food pass (y/n): " );
			foodPass = sc.next();
			
			if (foodPass.equals("y"))
				hasFoodPass = true;
			else if (foodPass.equals("n"))
				hasFoodPass = false;
			else
				System.out.println("Please Enter y or n!");
			
			StudentArrayList.add(new Student(name,surname,id,hasFoodPass));
			cafeteria.add(new Student(name,surname,id,hasFoodPass));
			studentCount ++;
			
			
		}else if(input.equals("2")) {
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.nextLine();
			System.out.printf("%s","Surname: ");
			surname = sc.nextLine();
			System.out.printf("%s","ID: ");
			id = sc.nextLine();
			System.out.printf("%s","Does the student have food pass (y/n): " );
			foodPass = sc.nextLine();
			
			if (foodPass.equals("y"))
				hasFoodPass = true;
			else if (foodPass.equals("n"))
				hasFoodPass = false;
			else
				System.out.println("Please Enter y or n!");
			
			System.out.printf("%s","Thesis Name: ");
			thesisName = sc.nextLine();
			
			StudentArrayList.add(new MasterStudent(name,surname,id,hasFoodPass,thesisName));
			cafeteria.add(new MasterStudent(name,surname,id,hasFoodPass,thesisName));
			studentCount++;
		
			
		}else if(input.equals("3")) {
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.nextLine();
			System.out.printf("%s","Surname: ");
			surname = sc.nextLine();
			System.out.printf("%s","ID: ");
			id = sc.nextLine();
			System.out.printf("%s","Does the student have food pass (y/n): " );
			foodPass = sc.nextLine();
			
			if (foodPass.equals("y"))
				hasFoodPass = true;
			else if (foodPass.equals("n"))
				hasFoodPass = false;
			else
				System.out.println("Please Enter y or n!");
			
			System.out.printf("%s","Thesis Name: ");
			thesisName = sc.nextLine();
			System.out.printf("%s","Lecture Hours: ");
			lectureHours = sc.nextInt();
			
			StudentArrayList.add(new PhDStudent(name,surname,id,hasFoodPass,thesisName,lectureHours));
			cafeteria.add(new PhDStudent(name,surname,id,hasFoodPass,thesisName,lectureHours));
			studentCount++;
			
					
		}else if(input.equals("4")) {
			
			Collections.shuffle(StudentArrayList);
			System.out.println("List is shuffled...");
			
			Iterator itr = StudentArrayList.iterator();
			
			while (itr.hasNext()) {
				Student a = (Student)itr.next();
				a.displayStudents();
			}
			
			
		}else if(input.equals("5")) {
			
			System.out.printf("%s","The number of created student objects: " + studentCount);
			
			
		}else if(input.equals("6")) {
			
			String givenid = null;
			
			Scanner scanner = new Scanner(System.in);
			System.out.printf("%s","Enter the student ID to search the list: ");
			givenid = scanner.nextLine();
			
			Iterator itr = StudentArrayList.iterator();
			
			while(itr.hasNext()) {
				
				Student a = (Student)itr.next();
				
				if((a.getId()).equals(givenid)) {
					System.out.println("Found " + a.getName()+" " + a.getSurname());
					System.out.println("Removing...");
					itr.remove();
					studentCount--;
				}					
			}
			
		}else if(input.equals("7")) {
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.nextLine();
			System.out.printf("%s","Surname: ");
			surname = sc.nextLine();
		
			cafeteria.add(new Personnel(name,surname));
					
			
		}else if(input.equals("8")) {
			
			Iterator iterator = cafeteria.iterator();
			System.out.println("Initiating food Service ...");
			System.out.println();
			
			while(iterator.hasNext()) {
				
				Cafeteria a = (Cafeteria)iterator.next();
				a.serveFood();	
				System.out.println();
			}		
			
		}else if(input.equals("0")) {
			break;
		}
		
		System.out.println();	
	}
}
	
}
