package lab8_20190702001;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javax.swing.*;

public class LW8 {
	
	public static void main(String args[]) {
		
		JFrame frame = new JFrame("LW8");
		frame.setLayout(null);
		
		JLabel lbl1 = new JLabel("Name:");
		frame.add(lbl1);
		lbl1.setBounds(10, 20, 5, 5); 
		JTextField name = new JTextField("Please enter a name ", 20);
		frame.add(name);
		
		JLabel lbl2 = new JLabel("Surname: ");
		frame.add(lbl2);
		JTextField surname = new JTextField("Please enter a surname", 20);
		frame.add(surname);
		
		JLabel lbl3 = new JLabel("ID: ");
		frame.add(lbl3);
		JTextField id = new JTextField("Please enter an ID ", 20);
		frame.add(id);
		
		JLabel lbl4 = new JLabel("Password: ");
		frame.add(lbl4);
		JTextField password = new JTextField("", 20);
		frame.add(password);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JButton button1 = new JButton("Save");
		
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent a) {
				
				FileWriter writer;
		    	  try {
		    		  writer = new FileWriter("lab8.txt",true);
		    		  
		    		  String name1 = name.getText();
		    		  
		    		  String surname1 = surname.getText();
		    		
		    		  String id1 = id.getText();
		    		  
		    		  String password1 = password.getText();
		    		  
		    		  writer.write(name1 + " " + surname1 + " " + id1 + " " + password1);
		      
		    		  writer.close();
		    	  }
		    	  catch (IOException e) {
   	
		    		  e. printStackTrace();
		    	  }
		      	}
			
		});
	
		frame.add(button1);
		frame.setSize(300, 200);
		frame.setVisible(true);

	}
}