package lab1;

import java.util.Scanner;

public class StudentArray {
	private String name;
	private String surname;
	private String id;
	
	
	public StudentArray(String name,String surname,String id) {
		this.name = name;
		this.surname = surname;
		this.id = id;
	
	}
	public StudentArray(String name,String surname) {
		this(name,surname,"0000");
	}
	
	public String getName() {
		return name;
	}

	public String getSurname() {
		return surname;
	}
	public String getId() {
		return id;
	}
}



