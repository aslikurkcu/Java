package lab1;

import java.util.Scanner;

public class StudentArrayTest {
	public static void main(String[] args) {
		
		
		StudentArray[] staff = new StudentArray[10];
		int i = 0;
		staff[0] = new StudentArray("asli","asd","123");
		while(true) {
		
		String input;
		
		
		System.out.println("1. Create a student");
		System.out.println("2. Create a student with ID");
		System.out.println("3. Display all students");
		System.out.println("0. Exit");
		
		Scanner myScanner = new Scanner(System.in);
		input = myScanner.nextLine();
		
		if(input.equals("1")){
			
			String name = null;
			String surname = null;
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.next();
			System.out.printf("%s","Surname: ");
			surname = sc.next();
			staff[i] = new StudentArray(name,surname);
			i++;
			
		}else if(input.equals("2")) {
			
			String name = null ;
			String surname = null;
			String id = null;
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.next();
			System.out.printf("%s","Surname: ");
			surname = sc.next();
			System.out.printf("%s","ID: ");
			id = sc.next();
			staff[i] = new StudentArray(name,surname,id);
			i++;
			
		}else if(input.equals("3")) {
			for(int a=0; a<i; a++) {
				System.out.println("Name: " + staff[a].getName());
				System.out.println("Surame: " + staff[a].getSurname());
				System.out.println("Name: " + staff[a].getId());
				System.out.println();
			}
		}else if(input.equals("0")) {
			break;
		}
	

		
	}
}
	
}
