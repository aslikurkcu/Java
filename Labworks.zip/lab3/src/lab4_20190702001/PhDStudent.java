package lab4_20190702001;

class PhDStudent extends MasterStudent{
	
	PhDStudent(String name,String surname,String id, String thesisName, int lectureHours){
		
		super(name, surname, id, thesisName);
		this.lectureHours = lectureHours;
	}		

public void displayStudents() {
	
	super.displayStudents();
	System.out.println("Lecture Hours: "+ this.lectureHours);
	
	}
}