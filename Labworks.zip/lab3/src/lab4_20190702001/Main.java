package lab4_20190702001;

import java.util.ArrayList;
import java.util.Scanner;

public class Main{
	
public static void main(String[] args) {
		
		String name;
		String surname;
		String id;
		String thesisName;
		int lectureHours;
		String input;
		int studentCount = 0;
		
		ArrayList<Student> StudentArrayList = new ArrayList<Student>();
		
		while(true) {
		
		System.out.println(MenuItems.M1.getMenu());
		System.out.println(MenuItems.M2.getMenu());
		System.out.println(MenuItems.M3.getMenu());
		System.out.println(MenuItems.M4.getMenu());
		System.out.println(MenuItems.M5.getMenu());
		System.out.println(MenuItems.M6.getMenu());
		
		
		
		Scanner myScanner = new Scanner(System.in);
		input = myScanner.nextLine();
		System.out.println();
		
		if(input.equals("1")){
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.next();
			System.out.printf("%s","Surname: ");
			surname = sc.next();
			System.out.printf("%s","ID: ");
			id = sc.next();
			StudentArrayList.add(new Student(name,surname,id));
			studentCount ++;
			
			
		}else if(input.equals("2")) {
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.next();
			System.out.printf("%s","Surname: ");
			surname = sc.next();
			System.out.printf("%s","ID: ");
			id = sc.next();
			System.out.printf("%s","Thesis Name: ");
			thesisName = sc.next();
			StudentArrayList.add(new MasterStudent(name,surname,id,thesisName));
			studentCount++;
		
			
		}else if(input.equals("3")) {
			
			Scanner sc = new Scanner(System.in);
			System.out.printf("%s","Name: ");
			name = sc.next();
			System.out.printf("%s","Surname: ");
			surname = sc.next();
			System.out.printf("%s","ID: ");
			id = sc.next();
			System.out.printf("%s","Thesis Name: ");
			thesisName = sc.next();
			System.out.printf("%s","Lecture Hours: ");
			lectureHours = sc.nextInt();
			StudentArrayList.add(new PhDStudent(name,surname,id,thesisName,lectureHours));
			studentCount++;
			
					
		}else if(input.equals("4")) {
			
			for (int a=0; a < studentCount ; a++) {
				StudentArrayList.get(a).displayStudents();
			}
			
		}else if(input.equals("5")) {
			
			System.out.printf("%s","The number of created student objects: " + studentCount);
			
		}else if(input.equals("0")) {
			break;
		}
		
		System.out.println();	
	}
}
	
}

