package lab4_20190702001;

class MasterStudent extends Student{
	
	MasterStudent(String name,String surname,String id, String thesisName){
		
		super(name, surname, id);
		this.thesisName = thesisName;
	}
			
public void displayStudents() {
		
	super.displayStudents();
	System.out.println("Thesis Name: "+ this.thesisName);
	
	}
}