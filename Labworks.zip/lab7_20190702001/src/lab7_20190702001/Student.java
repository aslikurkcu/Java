package lab7_20190702001;

import java.util.Scanner;

public class Student implements Cafeteria,Comparable<Student>{
	
	private String name;
	private String surname;
	private int id;
	String thesisName;
	int lectureHours;
	boolean hasFoodPass;
	

public int compareTo(Student a) {
	return this.id - a.getId();
}
	
public Student(String name,String surname,int id,Boolean hasFoodPass) {
	this.name = name;
	this.surname = surname;
	this.id = id;
	this.hasFoodPass = hasFoodPass;
}

public String getName() {
	return name;
}

public String getSurname() {
	return surname;
}

public int getId() {
	return id;
}

public Boolean getFoodPass() {
	return hasFoodPass;
}

public void displayStudents(){
		
		System.out.println();
		System.out.println("Name: " + getName());
		System.out.println("Surname: " + getSurname());
		System.out.println("ID: " + getId());
		
}

@Override
public void serveFood() {
	
	String FoodPass;
	Scanner scanner = new Scanner(System.in);
	
	if (getFoodPass() == true) 
		System.out.println("Serving food for " + getName() + " " + getSurname() + ": Has a food coupon, food is served. ");
	else {
		System.out.println("Serving food for " + getName() + " " + getSurname() + ": Does not have a food coupon.");
		System.out.printf("%s","The food is $5. Are you going to pay (y/n): ");
		FoodPass = scanner.nextLine();
		
		if (FoodPass.equals("y"))
			System.out.println("Food is served.");
		else if (FoodPass.equals("n"))
			System.out.println("Food is not served.");
		else 
			System.out.println("Please Enter y or n!");		
	}
}

}