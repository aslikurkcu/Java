package lab7_20190702001;

enum MenuItems {
	
	M1("1. Create a student"), 
	M2("2. Create a MasterStudent"),
	M3("3. Create a PhDStudent"),
	M4("4. Display all students"),
	M5("5. Display the student count"),
	M6("6. Find and remove a student"),
	M7("7. Add a personnel"),
	M8("8. Serve people waiting in cafeteria line"),
	M9("0.Exit");

	private String menu ;

	MenuItems(String m) {
		menu = m;
	}

	String getMenu() {
		return menu;
	}
	
	static void printMenu(){
		
		System.out.println(M1.getMenu());
		System.out.println(M2.getMenu());
		System.out.println(M3.getMenu());
		System.out.println(M4.getMenu());
		System.out.println(M5.getMenu());
		System.out.println(M6.getMenu());
		System.out.println(M7.getMenu());
		System.out.println(M8.getMenu());
		System.out.println(M9.getMenu());
		
	}
}