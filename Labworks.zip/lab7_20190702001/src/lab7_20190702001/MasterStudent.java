package lab7_20190702001;

import java.util.Scanner;

class MasterStudent extends Student{
	
	MasterStudent(String name,String surname,int id,Boolean hasFoodPass,String thesisName){
		
		super(name,surname,id,hasFoodPass);
		this.thesisName = thesisName;
	}
	
@Override			
public void displayStudents() {
		
	super.displayStudents();
	System.out.println("Thesis Name: "+ this.thesisName);
	
	}

@Override
public void serveFood() {
	
	String FoodPass;
	Scanner scanner = new Scanner(System.in);
	
	if (getFoodPass() == true) 
		System.out.println("Serving food for " + getName() + " " + getSurname() + ": Has a food coupon, food is served. ");
	else {
		System.out.println("Serving food for " + getName() + " " + getSurname() + ": Does not have a food coupon.");
		System.out.printf("%s","The food is $10. Are you going to pay (y/n): ");
		FoodPass = scanner.nextLine();
		
		if (FoodPass.equals("y"))
			System.out.println("Food is served.");
		else if (FoodPass.equals("n")) 
			System.out.println("Food is not served.");
		else
			System.out.println("Please Enter y or n!");
	}
}

}