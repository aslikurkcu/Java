package lab7_20190702001;

public interface Cafeteria {
	void serveFood();

}
